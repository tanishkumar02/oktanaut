---
title: Prepare your SCIM API service
excerpt: Prepare a SCIM-compliant API server to host your SCIM service, and test it to make sure it is working correctly.
meta:
  - name: description
    content: Prepare a SCIM-compliant API server to host your SCIM service, and test it to make sure it is working correctly.
layout: Guides
sections:
 - main
---