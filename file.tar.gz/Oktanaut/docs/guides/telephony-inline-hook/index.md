---
title: Telephony inline hook
excerpt: Learn how to easily implement a telephony inline hook
layout: Guides
sections:
 - main
---