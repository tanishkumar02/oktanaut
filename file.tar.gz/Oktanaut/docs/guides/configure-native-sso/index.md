---
title: Configure SSO for Native apps
excerpt: How to configure SSO for Native apps
layout: Guides
sections:
- main
---

