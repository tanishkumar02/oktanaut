---
title: Configure Okta sign-on and app sign-on policies
excerpt: How to configure an Okta sign-on policy and an app sign-on policy.
layout: Guides
sections:
 - main
---