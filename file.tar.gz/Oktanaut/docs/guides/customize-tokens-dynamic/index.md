---
title: Customize tokens returned from Okta with a dynamic allow list
excerpt: Define Groups claims for tokens returned from Okta.
layout: Guides
sections:
 - main
---