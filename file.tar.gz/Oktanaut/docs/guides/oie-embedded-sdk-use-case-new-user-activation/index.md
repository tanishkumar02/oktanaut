---
title: New user activation
layout: Guides
sections:
 - main
---
