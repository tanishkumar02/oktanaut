---
title: Style the Sign-In Widget
excerpt: Learn how to customize the self-hosted and Okta-hosted Sign-In Widget.
layout: Guides
sections:
 - main
---