---
title: Connect your SCIM API service to Okta
excerpt: Create and configure SCIM integrations, and check the attributes and their corresponding mappings in the Okta console.
meta:
  - name: description
    content: Create and configure SCIM integrations, and check the attributes and their corresponding mappings in the Okta console.
layout: Guides
sections:
 - main
---