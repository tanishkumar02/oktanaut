---
title: Test your Okta SCIM integration
excerpt: Test that your SCIM application can handle actual requests to Create, Read, Update and Delete (CRUD) user profile information, and run through our Okta Integration Network (OIN) quality assurance test cases.
meta:
  - name: description
    content: Test that your SCIM application can handle actual requests to Create, Read, Update and Delete (CRUD) user profile information, and run through our Okta Integration Network (OIN) quality assurance test cases.
layout: Guides
sections:
 - main
---