---
title: Transactional verification using CIBA
excerpt: How to implement transactional verification with CIBA and a custom authenticator
layout: Guides
sections:
- main
---