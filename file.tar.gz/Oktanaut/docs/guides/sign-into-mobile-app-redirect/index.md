---
title: Sign users in to your mobile app using the redirect model
excerpt: Configure your Okta org and your mobile app to use Okta’s redirect sign-in flow.
layout: Guides
sections:
 - main
---
