---
title: Set up OAuth 2.0 On-Behalf-Of Token Exchange
excerpt: This guide discusses how to retain user context in requests to downstream services using On-Behalf-Of Token Exchange with a single custom authorization server or between other custom authorization servers under the same Okta tenant.
layout: Guides
sections:
 - main
---