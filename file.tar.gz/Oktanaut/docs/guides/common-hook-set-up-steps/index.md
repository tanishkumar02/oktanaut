---
title: Common hook setup steps
excerpt: Overview and considerations when implementing an event or inline hook
layout: Guides
sections:
 - main
---