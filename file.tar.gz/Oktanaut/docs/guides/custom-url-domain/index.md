---
title: Customize the Okta URL and email notification domains
excerpt: Learn how to add a custom domain name to your Okta organization and configure a custom email notification domain.
layout: Guides
sections:
 - main
---
