---
title: Add a Login.gov Identity Provider
excerpt: Okta supports authentication with Login.gov as an external Identity Provider. Set up the Login.gov IdP using OpenID Connect with private key JWT in Okta.
layout: Guides
sections:
  - main
---