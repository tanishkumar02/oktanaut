---
title: Use redirect auth with the Identity Engine sample apps
excerpt: Learn how to test some of the features of Okta Identity Engine with our sample apps
layout: Guides
sections:
 - main
---