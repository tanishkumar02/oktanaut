---
title: Understand how sessions work after the upgrade
meta:
  - name: description
    content: Learn how sessions work with the Okta Identity Engine.
layout: Guides
sections:
  - main
---