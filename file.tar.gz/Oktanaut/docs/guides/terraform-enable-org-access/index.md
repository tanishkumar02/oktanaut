---
title: Enable Terraform access for your Okta org
meta:
  - name: description
    content: Create an Okta application and credentials that Terraform uses to manage the objects in your org.
layout: Guides
sections:
 - main
---
