---
title: Token inline hook
excerpt: Learn how to easily implement a token inline hook
layout: Guides
sections:
 - main
---