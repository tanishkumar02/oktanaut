---
title: Customize email notifications and domains
excerpt: Learn how to customize and style the default email notifications that Okta sends to end users and customize email domains.
layout: Guides
sections:
  - main
---