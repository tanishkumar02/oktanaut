---
title: Bulk migration with credentials
meta:
  - name: description
    content: Perform a bulk migration of users into Okta using the Okta API
layout: Guides
sections:
  - main
---