---
title: Basic sign-in flow using the Widget
layout: Guides
sections:
 - main
---