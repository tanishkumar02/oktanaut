---
title: Sign in to SPA with embedded Widget
excerpt: Front-end framework guides for the embedded Okta Sign-In Widget
sections:
 - main
---