---
title: Upgrade your widget
layout: Guides
sections:
 - main
---