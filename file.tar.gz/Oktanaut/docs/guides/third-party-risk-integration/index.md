---
title: Third-party risk provider integration
excerpt: Provides documentation on configuring an Okta org to receive risk events from a third-party provider
layout: Guides
sections:
 - main
---