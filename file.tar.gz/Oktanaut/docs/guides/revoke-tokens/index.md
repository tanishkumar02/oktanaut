---
title: Revoke Tokens
excerpt: How to revoke tokens with Okta
layout: Guides
sections:
- main
---
