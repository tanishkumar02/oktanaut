---
title: Okta Sign-In Widget Guide
language: JavaScript
icon: code-javascript
excerpt: A drop-in widget with custom UI capabilities to power sign-in with Okta.
sections:
 - main
---