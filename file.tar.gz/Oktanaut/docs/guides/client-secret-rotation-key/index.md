---
title: Client secret rotation and key management
meta:
  - name: description
    content: Okta client secret rotation helps you rotate and manage your client secrets without service or app downtime. Additionally, you can generate public/private key pairs and manage them using the Admin Console.
layout: Guides
sections:
- main
---