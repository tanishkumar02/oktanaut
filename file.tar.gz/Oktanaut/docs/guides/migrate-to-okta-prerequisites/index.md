---
title: Migrate to Okta — Prerequisites
meta:
  - name: description
    content: Create a plan for migrating existing users to Okta.
layout: Guides
sections:
  - main
---
