---
title: Configure Okta sign-on and app sign-on Policies
excerpt: How to configure a global session policy and authentication policies.
layout: Guides
sections:
 - main
---