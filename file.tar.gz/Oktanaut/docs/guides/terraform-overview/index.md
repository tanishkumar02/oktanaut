---
title: Terraform overview
meta:
  - name: description
    content: Automate managing your Okta org using scripts and the command line with Terraform instead of using the Admin Console.
layout: Guides
sections:
 - main
---
