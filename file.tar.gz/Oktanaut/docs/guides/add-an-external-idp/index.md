---
title: Add an enterprise Identity Provider
meta:
  - name: description
    content: Okta supports authentication with external enterprise Identity Providers. Get an overview of the process and prerequisites, as well as the set up instructions.
sections:
  - main
---
