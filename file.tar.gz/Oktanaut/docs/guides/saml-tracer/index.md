---
title: Test SAML app implementation with SAML Tracer
excerpt: How to test SAML flows with the SAML Tracer Firefox extension
layout: Guides
sections:
 - main
---
