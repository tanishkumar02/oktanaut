---
title: Unlock a mobile app with biometrics
excerpt: Learn how to integrate biometric authentication like Face ID and Touch ID to your mobile apps that use Okta.
layout: Guides
sections: 
 - main
---
