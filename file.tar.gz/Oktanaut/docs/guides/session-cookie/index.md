---
title: Work with Okta session cookies
excerpt: How to retrieve a session cookie from Okta
layout: Guides
sections:
 - main
---
