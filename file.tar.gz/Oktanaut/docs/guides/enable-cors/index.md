---
title: Enable CORS
excerpt: Enable Cross-Origin Resource Sharing for your app
layout: Guides
sections:
 - main
---