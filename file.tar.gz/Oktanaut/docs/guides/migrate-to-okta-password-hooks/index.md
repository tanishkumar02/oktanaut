---
title: Import Users with Inline Password Hooks
meta:
  - name: description
    content: Migrate users into Okta as they authenticate using password import inline hooks
layout: Guides
sections:
  - main
---