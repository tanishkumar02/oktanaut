---
title: Create an authorization server
excerpt: How to set up a custom authorization server in Okta
layout: Guides
sections:
 - main
---
