---
title: Manage groups with Terraform
meta:
  - name: description
    content: Configure access to Okta applications and manage sign-in flows for groups of users.
layout: Guides
sections:
 - main
---
