---
title: Sign users into your web app using the redirect model
excerpt: Configure your Okta org and your web app to use Okta’s redirect sign in.
layout: Guides
sections:
 - main
---
