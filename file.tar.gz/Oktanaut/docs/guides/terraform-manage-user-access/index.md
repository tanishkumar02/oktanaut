---
title: Manage user access with Terraform
meta:
  - name: description
    content: Automate the policies that control how end users authenticate to and access Okta applications.
layout: Guides
sections:
 - main
---
