---
title: Manage authentication services with Terraform
meta:
  - name: description
    content: Enable users to sign in using a trusted external Identity Provider.
layout: Guides
sections:
 - main
---
