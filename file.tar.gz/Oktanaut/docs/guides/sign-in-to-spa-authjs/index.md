---
title: Sign in to your SPA with Auth JS
excerpt: Learn how to add embedded authentication to your SPA app with Okta Auth JS.
layout: Guides
sections:
 - main
---
