---
title: Auth JS fundamentals
language: JavaScript
icon: code-javascript
excerpt: A JavaScript wrapper for Okta's Authentication APIs. Formerly titled "Okta Auth SDK Guide"
sections:
 - main
---