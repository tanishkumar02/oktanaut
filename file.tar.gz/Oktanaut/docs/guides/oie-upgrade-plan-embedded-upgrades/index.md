---
title: Plan embedded auth app upgrades
layout: Guides
sections:
  - main
---