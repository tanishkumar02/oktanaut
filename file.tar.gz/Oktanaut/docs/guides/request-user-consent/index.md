---
title: Request user consent
excerpt: How to request user consent during authentication
layout: Guides
sections:
- main
---
