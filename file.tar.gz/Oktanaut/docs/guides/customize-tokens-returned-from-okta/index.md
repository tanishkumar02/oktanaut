---
title: Customize tokens returned from Okta with custom claims
excerpt: Define custom claims and Groups claims for tokens returned from Okta.
layout: Guides
sections:
 - main
---