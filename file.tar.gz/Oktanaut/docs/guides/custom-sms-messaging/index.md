---
title: Customize SMS messages
excerpt: Learn how to customize the SMS messages sent to your users.
layout: Guides
sections:
 - main
---