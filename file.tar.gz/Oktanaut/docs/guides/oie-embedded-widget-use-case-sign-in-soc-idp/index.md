---
title: Sign in with Facebook using the Widget
layout: Guides
sections:
 - main
---