---
title: Deprecated JavaScript methods in the widget
layout: Guides
sections:
 - main
---