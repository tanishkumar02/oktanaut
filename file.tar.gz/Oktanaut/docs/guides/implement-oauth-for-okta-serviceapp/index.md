---
title: Implement OAuth for Okta with a service app
excerpt: Learn how to interact with Okta APIs by using scoped OAuth 2.0 access tokens for a service app.
layout: Guides
sections:
 - main
---