---
title: Sign in to your SPA with the embedded Okta Sign-In Widget
layout: Guides
sections:
 - main
---