---
title: Device Authorization Grant
excerpt: How to use a secondary device to complete sign-in to applications
layout: Guides
sections:
- main
---

