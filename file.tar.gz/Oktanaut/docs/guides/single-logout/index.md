---
title: Configure Single Logout
excerpt: Configure Single Logout for your SAML and OpenID Connect apps.
layout: Guides
sections:
 - main
---
