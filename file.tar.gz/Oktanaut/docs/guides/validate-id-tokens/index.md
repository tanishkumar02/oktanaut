---
title: Validate ID Tokens
excerpt: How to validate ID tokens with Okta
layout: Guides
sections:
 - main
---
