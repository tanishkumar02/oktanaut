---
title: Sign users out
excerpt: Learn how to sign users out of your applications that use Okta's APIs.
layout: Guides
sections:
 - main
---
