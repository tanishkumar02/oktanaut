---
title: Build a Single Sign-On (SSO) integration
excerpt: Build an SSO app integration using SAML or OIDC for the OIN.
meta:
  - name: description
    content: Use this guide to learn how to build a federated Single Sign-On integration with Okta.
layout: Guides
sections:
 - main
---
