---
title: Share application key credentials for IdPs across Apps
excerpt: How to share application key credentials between Apps
layout: Guides
sections:
 - main
---
