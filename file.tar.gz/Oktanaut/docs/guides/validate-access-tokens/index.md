---
title: Validate Access Tokens
excerpt: How to validate access tokens with Okta.
layout: Guides
meta:
  - name: description
    content: This guide on tokens shows you how to verify a token's signature, manage key rotation, and how to use a refresh token to get a new access token.
sections:
 - main
---
