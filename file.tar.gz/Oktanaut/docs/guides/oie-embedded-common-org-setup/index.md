---
title: Set up your Okta org
excerpt: Create and set up your Okta org for embedded authentication
layout: Guides
sections:
 - main
---
