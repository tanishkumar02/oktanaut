---
title: Add the Identity Engine SDK to your app
excerpt: Add and upgrade your application to the Identity Engine SDK
layout: Guides
sections:
 - main
---
