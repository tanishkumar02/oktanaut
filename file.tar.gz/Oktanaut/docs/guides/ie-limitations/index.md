---
title: Identity Engine limitations
excerpt: Okta Identity Engine introduces a lot of changes to the Okta platform. Some of these changes result in a lack of support for previously available features.
layout: Guides
sections:
  - main
---