---
title: Configure user-scoped account management
meta:
  - name: description
    content: The MyAccount API now provides user-scoped endpoints that don’t require admin tokens. End users only need a bearer token to update their profile, or email and phone authenticators.
layout: Guides
sections:
 - main
---