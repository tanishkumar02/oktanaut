---
title: SAML assertion inline hook
excerpt: Learn how to easily implement a SAML assertion inline hook
layout: Guides
sections:
 - main
---