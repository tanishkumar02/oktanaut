---
title: Embedded Okta Sign-In Widget fundamentals
layout: Guides
sections:
 - main
---