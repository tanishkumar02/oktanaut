---
title: Auth JS redirect guide
layout: Guides
sections:
 - main
---