---
title: Build a JWT for Client Authentication
excerpt: Learn how to build a self-signed JWT.
layout: Guides
sections: 
 - main
---
