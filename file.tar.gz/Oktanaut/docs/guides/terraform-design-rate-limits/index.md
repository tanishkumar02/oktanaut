---
title: Optimize Terraform access to Okta APIs
meta:
  - name: description
    content: Optimize your configuration to reduce the number of API calls that Terraform makes, and set custom rate limits to stop Terraform before you reach your org’s rate limits.
layout: Guides
sections:
 - main
---
