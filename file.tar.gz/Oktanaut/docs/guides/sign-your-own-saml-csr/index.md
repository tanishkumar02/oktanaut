---
title: Sign the Okta certificate with your own CA
excerpt: How to use a custom SAML certificate for apps
layout: Guides
sections:
- main
---
