---
title: Download and set up the SDK, Sign-In Widget, and sample apps
excerpt: Download and set up the SDK, Sign-In Widget, and sample apps
layout: Guides
sections:
 - main
---
