---
title: User sign out (local app)
layout: Guides
sections:
 - main
---