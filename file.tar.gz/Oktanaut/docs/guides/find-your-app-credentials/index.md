---
title: Find your application credentials
excerpt: Find your Okta app's client ID and secret
layout: Guides
sections:
- main
---
