---
title: Set up self-service registration
meta:
  - name: description
    content: Okta's self-service registration lets you configure a custom app or the Okta homepage for use when users self-register.
layout: Guides
sections:
 - main
---