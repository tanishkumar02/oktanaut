---
title: Create an API token
excerpt: How to create a token for the Okta API
layout: Guides
sections:
 - main
---
