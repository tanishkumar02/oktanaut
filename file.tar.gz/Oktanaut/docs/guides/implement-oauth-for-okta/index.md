---
title: Implement OAuth for Okta
excerpt: Learn how to interact with Okta APIs by using scoped OAuth 2.0 access tokens.
layout: Guides
sections:
 - main
---