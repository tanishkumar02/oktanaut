---
title: Upgrade your application to the Identity Engine SDK
layout: Guides
sections:
 - main
---