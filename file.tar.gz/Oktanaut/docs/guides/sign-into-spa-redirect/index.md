---
title: Sign users in to your SPA using the redirect model
excerpt: Configure your Okta org and your single-page app to use Okta’s redirect sign-in flow.
layout: Guides
sections:
 - main
---
