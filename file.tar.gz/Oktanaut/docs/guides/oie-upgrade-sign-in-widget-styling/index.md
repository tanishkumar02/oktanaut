---
title: Updates to widget styling
layout: Guides
sections:
 - main
---