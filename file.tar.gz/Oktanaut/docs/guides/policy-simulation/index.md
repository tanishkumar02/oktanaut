---
title: Test your policies with Access simulations
excerpt: Provides documentation on testing your policies using the Policy APIs simulate endpoint
layout: Guides
sections:
 - main
---