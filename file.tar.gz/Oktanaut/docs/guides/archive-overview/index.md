---
title: Okta Classic Engine overview
excerpt: The Okta Classic Engine section contains Okta classic-compatible versions of documents that have been updated to support Okta Identity Engine.
sections:
 - main
---