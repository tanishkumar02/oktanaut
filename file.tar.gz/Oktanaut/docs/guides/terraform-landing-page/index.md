---
title: Automate org management with Terraform
meta:
  - name: description
    content: Use code in Terraform and the command line to manage groups, users, policies, and other parts of your Okta org.
layout: Guides
sections:
 - main
---
