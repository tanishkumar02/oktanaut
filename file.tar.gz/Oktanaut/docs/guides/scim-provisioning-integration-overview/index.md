---
title: Build a SCIM provisioning integration overview
excerpt: Create a provisioning integration with SCIM in Okta.
meta:
  - name: description
    content: Use this guide to learn about the steps required to build an Okta integration that uses SCIM to handle user provisioning.
layout: Guides
sections:
 - main
---