---
title: Updates to widget I18n properties
layout: Guides
sections:
 - main
---