---
title: Understand authenticator enrollment policy API changes after the upgrade
meta:
  - name: description
    content: Learn how to use and manage authenticator enrollment policies with the API in Okta Identity Engine.
layout: Guides
sections:
  - main
---