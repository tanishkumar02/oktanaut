---
title: Add a social Identity Provider
meta:
  - name: description
    content: Okta supports authentication with social Identity Providers. Get an overview of the social login process and prerequisites, as well as the setup instructions.
sections:
- main
---